package com.example.catsminesgame.screens.settings

class SettingsViewModel {
}